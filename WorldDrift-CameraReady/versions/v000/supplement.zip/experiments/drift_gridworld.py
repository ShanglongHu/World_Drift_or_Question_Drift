"""Minimal neural action-conditioned world-model experiment.

The model predicts terminal occupancy and whether any collision occurs for a
declared action sequence.  Training first exposes q_left_3 and then q_right_5.
The baselines differ only in whether the query is represented and whether old
samples are replayed.
"""

from __future__ import annotations

import csv
import random
from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F


GRID = 11
N_STATES = GRID * GRID
MAX_HORIZON = 5
N_ACTIONS = 4
PAD = 4
SEEDS = 10
BATCH = 96
PHASE_STEPS = 600
REPLAY_FRACTION = 0.2
QUERIES = {
    "q_left_3": (2, 2, 2),
    "q_right_5": (3, 3, 3, 3, 3),
}


def wall_mask() -> np.ndarray:
    walls = np.zeros((GRID, GRID), dtype=bool)
    walls[[0, -1], :] = True
    walls[:, [0, -1]] = True
    walls[2:9, 5] = True
    walls[5, 5] = False
    return walls


WALLS = wall_mask()
FREE_STATES = np.asarray(
    [y * GRID + x for y in range(GRID) for x in range(GRID) if not WALLS[y, x]],
    dtype=np.int64,
)


def rollout(state: int, actions: tuple[int, ...]) -> tuple[int, float]:
    y, x = divmod(int(state), GRID)
    collided = False
    delta = {0: (-1, 0), 1: (1, 0), 2: (0, -1), 3: (0, 1)}
    for action in actions:
        dy, dx = delta[action]
        ny, nx = y + dy, x + dx
        if WALLS[ny, nx]:
            collided = True
        else:
            y, x = ny, nx
    return y * GRID + x, float(collided)


def query_features(name: str) -> np.ndarray:
    actions = QUERIES[name]
    tokens = list(actions) + [PAD] * (MAX_HORIZON - len(actions))
    encoded = np.zeros(MAX_HORIZON * (N_ACTIONS + 1) + MAX_HORIZON, dtype=np.float32)
    for index, token in enumerate(tokens):
        encoded[index * (N_ACTIONS + 1) + token] = 1.0
    encoded[MAX_HORIZON * (N_ACTIONS + 1) + len(actions) - 1] = 1.0
    return encoded


QUERY_FEATURES = {name: query_features(name) for name in QUERIES}
QUERY_DIM = len(next(iter(QUERY_FEATURES.values())))


class RolloutPredictor(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(N_STATES + QUERY_DIM, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
        )
        self.state_head = nn.Linear(128, N_STATES)
        self.collision_head = nn.Linear(128, 1)

    def forward(self, inputs: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        hidden = self.net(inputs)
        return self.state_head(hidden), self.collision_head(hidden).squeeze(-1)


@dataclass(frozen=True)
class Method:
    name: str
    conditioned: bool
    replay: bool


METHODS = (
    Method("shared head", conditioned=False, replay=False),
    Method("replay, no identity", conditioned=False, replay=True),
    Method("query-conditioned replay", conditioned=True, replay=True),
)


def make_batch(
    rng: np.random.Generator,
    question: str,
    conditioned: bool,
    size: int,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    states = rng.choice(FREE_STATES, size=size, replace=True)
    query = QUERY_FEATURES[question] if conditioned else np.zeros(QUERY_DIM, dtype=np.float32)
    inputs = np.zeros((size, N_STATES + QUERY_DIM), dtype=np.float32)
    inputs[np.arange(size), states] = 1.0
    inputs[:, N_STATES:] = query
    outcomes = [rollout(int(state), QUERIES[question]) for state in states]
    targets = np.asarray([outcome[0] for outcome in outcomes], dtype=np.int64)
    collisions = np.asarray([outcome[1] for outcome in outcomes], dtype=np.float32)
    return torch.from_numpy(inputs), torch.from_numpy(targets), torch.from_numpy(collisions)


def train_step(
    model: RolloutPredictor,
    optimizer: torch.optim.Optimizer,
    batches: list[tuple[torch.Tensor, torch.Tensor, torch.Tensor]],
) -> None:
    inputs = torch.cat([batch[0] for batch in batches])
    states = torch.cat([batch[1] for batch in batches])
    collisions = torch.cat([batch[2] for batch in batches])
    state_logits, collision_logits = model(inputs)
    loss = F.cross_entropy(state_logits, states) + F.binary_cross_entropy_with_logits(
        collision_logits, collisions
    )
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()


@torch.no_grad()
def evaluate(model: RolloutPredictor, question: str, conditioned: bool) -> float:
    rng = np.random.default_rng(12345)
    inputs, states, collisions = make_batch(
        rng, question, conditioned, size=len(FREE_STATES) * 4
    )
    state_logits, collision_logits = model(inputs)
    loss = F.cross_entropy(state_logits, states) + F.binary_cross_entropy_with_logits(
        collision_logits, collisions
    )
    return float(loss)


def run_seed(seed: int, method: Method) -> tuple[float, float]:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(1)
    rng = np.random.default_rng(seed)
    model = RolloutPredictor()
    optimizer = torch.optim.Adam(model.parameters(), lr=2e-3)

    for _ in range(PHASE_STEPS):
        batch = make_batch(rng, "q_left_3", method.conditioned, BATCH)
        train_step(model, optimizer, [batch])

    for _ in range(PHASE_STEPS):
        new_size = BATCH
        batches = []
        if method.replay:
            old_size = int(BATCH * REPLAY_FRACTION)
            new_size -= old_size
            batches.append(make_batch(rng, "q_left_3", method.conditioned, old_size))
        batches.append(make_batch(rng, "q_right_5", method.conditioned, new_size))
        train_step(model, optimizer, batches)

    return (
        evaluate(model, "q_left_3", method.conditioned),
        evaluate(model, "q_right_5", method.conditioned),
    )


def main() -> None:
    all_results: dict[str, np.ndarray] = {}
    for method in METHODS:
        values = np.asarray([run_seed(seed, method) for seed in range(SEEDS)])
        all_results[method.name] = values

    output_dir = Path(__file__).parent
    with (output_dir / "drift_gridworld_results.csv").open(
        "w", newline="", encoding="utf-8"
    ) as stream:
        writer = csv.writer(stream)
        writer.writerow(["method", "query", "loss_mean", "loss_se"])
        for method, values in all_results.items():
            means = values.mean(axis=0)
            ses = values.std(axis=0, ddof=1) / np.sqrt(SEEDS)
            for index, question in enumerate(("old_q_left_3", "current_q_right_5")):
                writer.writerow([method, question, means[index], ses[index]])
                print(f"{method:26s} {question:20s} {means[index]:.3f}+/-{ses[index]:.3f}")

    labels = list(all_results)
    means = np.asarray([all_results[label].mean(axis=0) for label in labels])
    ses = np.asarray(
        [all_results[label].std(axis=0, ddof=1) / np.sqrt(SEEDS) for label in labels]
    )
    x = np.arange(len(labels))
    width = 0.34
    fig, ax = plt.subplots(figsize=(6.4, 3.0))
    ax.bar(x - width / 2, means[:, 0], width, yerr=ses[:, 0], label="Old $q_{L,3}$")
    ax.bar(x + width / 2, means[:, 1], width, yerr=ses[:, 1], label="Current $q_{R,5}$")
    ax.set_yscale("log")
    ax.set_ylim(7e-4, 40)
    ax.set_yticks([1e-3, 1e-2, 1e-1, 1, 10])
    ax.set_ylabel("Loss (log scale)")
    ax.set_xticks(x, ["Shared\nhead", "Replay, no\nidentity", "Query-conditioned\nreplay"])
    ax.set_xlabel("Method")
    ax.legend(frameon=False, ncol=2, loc="upper right")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(output_dir / "drift_gridworld.pdf", bbox_inches="tight")
    fig.savefig(output_dir / "drift_gridworld.png", dpi=180, bbox_inches="tight")


if __name__ == "__main__":
    main()
