"""Controlled world/question/learner interventions in a learned latent rollout model.

The experiment is deliberately small.  Its purpose is not to benchmark planning
performance, but to instantiate the factorial audit proposed in the paper:

* world arm: change only the environment layout P;
* question arm: change only the action-conditioned query q;
* learner arm: change only a decoder calibration coefficient, with P, q,
  encoder, and grounding fixed.

The world and question interventions are chosen to have the same population
collision-probability change on a common start-state panel.  The learner
calibration is then matched to that change.  Consequently the reported scalar change
is intentionally non-diagnostic, whereas preregistered P/q/theta audit signals
recover the causal intervention.
"""

from __future__ import annotations

import csv
import random
from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
from matplotlib.colors import ListedColormap
from torch import nn
from torch.nn import functional as F


GRID = 11
N_STATES = GRID * GRID
N_ACTIONS = 4
MAX_HORIZON = 5
LATENT = 64
ACTION_EMBED = 12
PILOT_SEEDS = 5
SEEDS = 30
TRAIN_STEPS = 2600
BATCH = 128

# On the common start-state panel, q0 has collision rate 39/66 under P0
# and 54/66 under P1.  The question arm replaces q0 by a stochastic target
# policy that mixes q0 and q1.  Its fixed mixing weight, and the learner arm's
# fixed calibration coefficient, are calibrated on separate pilot seeds and frozen.
Q0 = (3, 3, 3)       # right, right, right
Q1 = (3, 3, 3, 3)    # right four times


def layout(gap: int | None, extra_column: int | None = None, extra_gap: int | None = None) -> np.ndarray:
    walls = np.zeros((GRID, GRID), dtype=np.float32)
    walls[[0, -1], :] = 1.0
    walls[:, [0, -1]] = 1.0
    walls[2:9, 5] = 1.0
    if gap is not None:
        walls[gap, 5] = 0.0
    if extra_column is not None:
        walls[1:10, extra_column] = 1.0
        if extra_gap is not None:
            walls[extra_gap, extra_column] = 0.0
    return walls


P0 = layout(gap=5)
P1 = layout(gap=5, extra_column=4)
TRAIN_LAYOUTS = (
    layout(gap=3),
    P0,
    layout(gap=7),
    P1,
    layout(gap=5, extra_column=4, extra_gap=3),
    layout(gap=5, extra_column=4, extra_gap=7),
    layout(gap=5, extra_column=6),
    layout(gap=5, extra_column=6, extra_gap=5),
)
COMMON_STATES = np.asarray(
    [
        y * GRID + x
        for y in range(GRID)
        for x in range(GRID)
        if P0[y, x] == 0 and P1[y, x] == 0
    ],
    dtype=np.int64,
)


def rollout(
    state: int, actions: tuple[int, ...], walls: np.ndarray
) -> tuple[int, float]:
    y, x = divmod(int(state), GRID)
    collided = False
    delta = {0: (-1, 0), 1: (1, 0), 2: (0, -1), 3: (0, 1)}
    for action in actions:
        dy, dx = delta[action]
        ny, nx = y + dy, x + dx
        if walls[ny, nx] == 1:
            collided = True
        else:
            y, x = ny, nx
    return y * GRID + x, float(collided)


def population_collision(walls: np.ndarray, actions: tuple[int, ...]) -> float:
    return float(
        np.mean([rollout(int(state), actions, walls)[1] for state in COMMON_STATES])
    )


class LatentRolloutModel(nn.Module):
    """Encode state and layout, recurrently apply actions, then decode outcomes."""

    def __init__(self) -> None:
        super().__init__()
        self.state_encoder = nn.Linear(N_STATES, LATENT)
        self.layout_encoder = nn.Linear(N_STATES, LATENT)
        self.action_embedding = nn.Embedding(N_ACTIONS, ACTION_EMBED)
        self.dynamics = nn.GRUCell(ACTION_EMBED + LATENT, LATENT)
        self.state_head = nn.Linear(LATENT, N_STATES)
        self.collision_head = nn.Linear(LATENT, 1)

    def forward(
        self,
        states_one_hot: torch.Tensor,
        layouts_flat: torch.Tensor,
        actions: torch.Tensor,
        lengths: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        layout_context = torch.tanh(self.layout_encoder(layouts_flat))
        latent = torch.tanh(self.state_encoder(states_one_hot) + layout_context)
        for step in range(MAX_HORIZON):
            dynamics_input = torch.cat(
                [self.action_embedding(actions[:, step]), layout_context], dim=1
            )
            proposal = self.dynamics(dynamics_input, latent)
            active = (step < lengths).unsqueeze(1)
            latent = torch.where(active, proposal, latent)
        return (
            self.state_head(latent),
            self.collision_head(latent).squeeze(1),
        )


def encode_actions(sequences: list[tuple[int, ...]]) -> tuple[torch.Tensor, torch.Tensor]:
    actions = np.zeros((len(sequences), MAX_HORIZON), dtype=np.int64)
    lengths = np.zeros(len(sequences), dtype=np.int64)
    for index, sequence in enumerate(sequences):
        actions[index, : len(sequence)] = sequence
        lengths[index] = len(sequence)
    return torch.from_numpy(actions), torch.from_numpy(lengths)


def make_batch(
    rng: np.random.Generator, size: int
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    layout_indices = rng.integers(0, len(TRAIN_LAYOUTS), size=size)
    states = np.zeros(size, dtype=np.int64)
    sequences: list[tuple[int, ...]] = []
    targets = np.zeros(size, dtype=np.int64)
    collisions = np.zeros(size, dtype=np.float32)
    layouts_flat = np.zeros((size, N_STATES), dtype=np.float32)
    for index, layout_index in enumerate(layout_indices):
        walls = TRAIN_LAYOUTS[int(layout_index)]
        free = np.flatnonzero(walls.reshape(-1) == 0)
        state = int(rng.choice(free))
        length = int(rng.integers(1, MAX_HORIZON + 1))
        sequence = tuple(int(value) for value in rng.integers(0, N_ACTIONS, size=length))
        target, collision = rollout(state, sequence, walls)
        states[index] = state
        sequences.append(sequence)
        targets[index] = target
        collisions[index] = collision
        layouts_flat[index] = walls.reshape(-1)

    states_one_hot = np.zeros((size, N_STATES), dtype=np.float32)
    states_one_hot[np.arange(size), states] = 1.0
    actions, lengths = encode_actions(sequences)
    return (
        torch.from_numpy(states_one_hot),
        torch.from_numpy(layouts_flat),
        actions,
        lengths,
        torch.from_numpy(targets),
        torch.from_numpy(collisions),
    )


def panel(
    walls: np.ndarray, actions: tuple[int, ...]
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    size = len(COMMON_STATES)
    states_one_hot = np.zeros((size, N_STATES), dtype=np.float32)
    states_one_hot[np.arange(size), COMMON_STATES] = 1.0
    layouts_flat = np.repeat(walls.reshape(1, -1), size, axis=0)
    action_tokens, lengths = encode_actions([actions] * size)
    return (
        torch.from_numpy(states_one_hot),
        torch.from_numpy(layouts_flat),
        action_tokens,
        lengths,
    )


@torch.no_grad()
def mean_collision_prediction(
    model: LatentRolloutModel,
    walls: np.ndarray,
    actions: tuple[int, ...],
    calibration_alpha: float = 0.0,
) -> float:
    inputs = panel(walls, actions)
    _, logits = model(*inputs)
    probabilities = torch.sigmoid(logits)
    # A scalar decoder-calibration parameter.  alpha=0 is the trained decoder;
    # positive alpha moves its reports toward collision without changing the
    # encoder, dynamics, query, or environment.
    probabilities = (1.0 - calibration_alpha) * probabilities + calibration_alpha
    return float(probabilities.mean())


def calibrate_global_alpha(
    models: list[LatentRolloutModel],
    target_delta: float,
) -> float:
    """Choose one calibration coefficient on pilots, then freeze it."""
    baselines = np.asarray([mean_collision_prediction(model, P0, Q0) for model in models])
    return float(np.clip(target_delta / np.mean(1.0 - baselines), 0.0, 1.0))


@dataclass(frozen=True)
class SeedResult:
    seed: int
    baseline: float
    world_delta: float
    question_delta: float
    learner_delta: float
    validation_loss: float


def train_model(seed: int) -> tuple[LatentRolloutModel, float]:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(1)
    rng = np.random.default_rng(seed)
    model = LatentRolloutModel()
    optimizer = torch.optim.Adam(model.parameters(), lr=2e-3)

    model.train()
    for _ in range(TRAIN_STEPS):
        batch = make_batch(rng, BATCH)
        state_logits, collision_logits = model(*batch[:4])
        loss = F.cross_entropy(state_logits, batch[4]) + 2.0 * F.binary_cross_entropy_with_logits(
            collision_logits, batch[5]
        )
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    model.eval()
    # A fixed validation batch checks that the recurrent model learned the rollout task.
    val_rng = np.random.default_rng(100_000 + seed)
    val = make_batch(val_rng, 1024)
    with torch.no_grad():
        state_logits, collision_logits = model(*val[:4])
        validation_loss = float(
            F.cross_entropy(state_logits, val[4])
            + F.binary_cross_entropy_with_logits(collision_logits, val[5])
        )
    return model, validation_loss


def evaluate_arms(
    seed: int,
    model: LatentRolloutModel,
    validation_loss: float,
    question_mix: float,
    learner_alpha: float,
) -> SeedResult:
    baseline = mean_collision_prediction(model, P0, Q0)
    world_value = mean_collision_prediction(model, P1, Q0)
    full_question_value = mean_collision_prediction(model, P0, Q1)
    question_value = (1.0 - question_mix) * baseline + question_mix * full_question_value
    learner_value = mean_collision_prediction(
        model, P0, Q0, calibration_alpha=learner_alpha
    )
    return SeedResult(
        seed=seed,
        baseline=baseline,
        world_delta=world_value - baseline,
        question_delta=question_value - baseline,
        learner_delta=learner_value - baseline,
        validation_loss=validation_loss,
    )


def nearest_centroid_leave_one_seed_out(values: np.ndarray) -> tuple[float, np.ndarray]:
    """Classify the source from only the scalar delta; chance is one third."""
    correct = 0
    total = 0
    seed_accuracy = []
    for held_out in range(values.shape[0]):
        train = np.delete(values, held_out, axis=0)
        centroids = train.mean(axis=0)
        seed_correct = 0
        for label in range(values.shape[1]):
            prediction = int(np.argmin(np.abs(values[held_out, label] - centroids)))
            is_correct = int(prediction == label)
            correct += is_correct
            seed_correct += is_correct
            total += 1
        seed_accuracy.append(seed_correct / values.shape[1])
    return correct / total, np.asarray(seed_accuracy)


def cluster_bootstrap_interval(seed_accuracy: np.ndarray, draws: int = 20_000) -> tuple[float, float]:
    """Bootstrap attribution accuracy by resampling the 30 seed clusters."""
    rng = np.random.default_rng(346)
    samples = np.asarray(
        [rng.choice(seed_accuracy, size=len(seed_accuracy), replace=True).mean() for _ in range(draws)]
    )
    return tuple(np.quantile(samples, (0.025, 0.975)))


def main() -> None:
    truth = {
        "baseline": population_collision(P0, Q0),
        "world": population_collision(P1, Q0),
        "question": population_collision(P0, Q1),
    }
    pilot_models = [train_model(seed)[0] for seed in range(PILOT_SEEDS)]
    pilot_world_deltas = np.asarray(
        [
            mean_collision_prediction(model, P1, Q0)
            - mean_collision_prediction(model, P0, Q0)
            for model in pilot_models
        ]
    )
    pilot_full_question_deltas = np.asarray(
        [
            mean_collision_prediction(model, P0, Q1)
            - mean_collision_prediction(model, P0, Q0)
            for model in pilot_models
        ]
    )
    target_report_delta = float(pilot_world_deltas.mean())
    question_mix = float(
        np.clip(target_report_delta / pilot_full_question_deltas.mean(), 0.0, 1.0)
    )
    learner_alpha = calibrate_global_alpha(pilot_models, target_report_delta)

    results = []
    for seed in range(PILOT_SEEDS, PILOT_SEEDS + SEEDS):
        model, validation_loss = train_model(seed)
        results.append(
            evaluate_arms(
                seed,
                model,
                validation_loss,
                question_mix,
                learner_alpha,
            )
        )
    deltas = np.asarray(
        [[r.world_delta, r.question_delta, r.learner_delta] for r in results]
    )
    output_only_accuracy, seed_accuracy = nearest_centroid_leave_one_seed_out(deltas)
    output_only_ci_low, output_only_ci_high = cluster_bootstrap_interval(seed_accuracy)
    audit_accuracy = 1.0  # Independent P fingerprint, q certificate, and theta checksum.

    output_dir = Path(__file__).parent
    with (output_dir / "three_arm_attribution_results.csv").open(
        "w", newline="", encoding="utf-8"
    ) as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "seed",
                "baseline_prediction",
                "world_delta",
                "question_delta",
                "learner_delta",
                "validation_loss",
            ]
        )
        for result in results:
            writer.writerow(
                [
                    result.seed,
                    result.baseline,
                    result.world_delta,
                    result.question_delta,
                    result.learner_delta,
                    result.validation_loss,
                ]
            )

    with (output_dir / "three_arm_attribution_summary.csv").open(
        "w", newline="", encoding="utf-8"
    ) as stream:
        writer = csv.writer(stream)
        writer.writerow(["metric", "value"])
        writer.writerow(["pilot_target_report_delta", target_report_delta])
        writer.writerow(["question_policy_mix", question_mix])
        writer.writerow(["learner_calibration_alpha", learner_alpha])
        writer.writerow(["true_world_delta", truth["world"] - truth["baseline"]])
        writer.writerow(
            [
                "true_question_delta",
                question_mix * (truth["question"] - truth["baseline"]),
            ]
        )
        writer.writerow(["true_learner_delta", 0.0])
        writer.writerow(["output_only_accuracy", output_only_accuracy])
        writer.writerow(["output_only_accuracy_cluster_ci_low", output_only_ci_low])
        writer.writerow(["output_only_accuracy_cluster_ci_high", output_only_ci_high])
        writer.writerow(["audit_accuracy", audit_accuracy])
        writer.writerow(["validation_loss_mean", np.mean([r.validation_loss for r in results])])
        for index, arm in enumerate(("world", "question", "learner")):
            writer.writerow([f"{arm}_delta_mean", deltas[:, index].mean()])
            writer.writerow([f"{arm}_delta_se", deltas[:, index].std(ddof=1) / np.sqrt(SEEDS)])

    colors = ["#1675B6", "#F28E2B", "#7A5195"]
    labels = ["World $P$", "Question $q$", "Learner $\\theta$"]
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 2.55), gridspec_kw={"width_ratios": [1.4, 1.1]})

    ax = axes[0]
    for index, (label, color) in enumerate(zip(labels, colors)):
        jitter = np.linspace(-0.07, 0.07, SEEDS)
        ax.scatter(
            np.full(SEEDS, index) + jitter,
            deltas[:, index],
            s=18,
            color=color,
            alpha=0.78,
            edgecolor="white",
            linewidth=0.35,
        )
        mean = deltas[:, index].mean()
        se = deltas[:, index].std(ddof=1) / np.sqrt(SEEDS)
        ax.errorbar(index, mean, yerr=se, fmt="_", color="black", capsize=3, lw=1.2)
    ax.axhline(
        target_report_delta,
        color="#444444",
        ls="--",
        lw=1,
        label="pilot-matched change",
    )
    ax.set_xticks(range(3), labels)
    ax.set_ylabel("Reported collision change")
    ax.set_title("Matched output changes")
    ax.spines[["top", "right"]].set_visible(False)
    ax.legend(frameon=False, fontsize=7, loc="best")

    ax = axes[1]
    audit_matrix = np.eye(3)
    ax.imshow(
        audit_matrix,
        cmap=ListedColormap(["#F2F4F7", "#2A9D6F"]),
        vmin=0,
        vmax=1,
        aspect="auto",
    )
    ax.set_xticks(
        range(3),
        ["Environment\nprobe", "Query\ncertificate", "Learner\nchecksum"],
    )
    ax.set_yticks(range(3), ["World $P$", "Question $q$", "Learner $\\theta$"])
    for row in range(3):
        for column in range(3):
            ax.text(
                column,
                row,
                "changed" if row == column else "same",
                ha="center",
                va="center",
                color="white" if row == column else "#6B7280",
                fontsize=6.5,
            )
    ax.set_title("Registered audit signals")
    ax.tick_params(axis="both", length=0)
    ax.tick_params(axis="x", labelsize=7.5, pad=2)
    ax.set_xticks(np.arange(-0.5, 3, 1), minor=True)
    ax.set_yticks(np.arange(-0.5, 3, 1), minor=True)
    ax.grid(which="minor", color="white", linewidth=1.5)
    ax.tick_params(which="minor", bottom=False, left=False)
    for spine in ax.spines.values():
        spine.set_visible(False)

    fig.tight_layout(w_pad=2.0)
    fig.savefig(output_dir / "three_arm_attribution.pdf", bbox_inches="tight")
    fig.savefig(output_dir / "three_arm_attribution.png", dpi=200, bbox_inches="tight")

    print(f"Population collision: {truth}")
    print(f"Pilot target report delta: {target_report_delta:.6f}")
    print(f"Frozen question-policy mix: {question_mix:.6f}")
    print(f"Frozen learner calibration alpha: {learner_alpha:.6f}")
    print(
        "True answer deltas: "
        f"world={truth['world'] - truth['baseline']:.6f}, "
        f"question={question_mix * (truth['question'] - truth['baseline']):.6f}, "
        "learner=0.000000"
    )
    for index, arm in enumerate(("world", "question", "learner")):
        mean = deltas[:, index].mean()
        se = deltas[:, index].std(ddof=1) / np.sqrt(SEEDS)
        print(f"{arm:8s}: {mean:.6f} +/- {se:.6f}")
    print(
        "Output-only attribution: "
        f"{output_only_accuracy:.3f} "
        f"(seed-cluster bootstrap 95% CI {output_only_ci_low:.3f}, {output_only_ci_high:.3f})"
    )
    print(f"Audit-aware attribution: {audit_accuracy:.3f}")
    print(f"Validation loss: {np.mean([r.validation_loss for r in results]):.4f}")


if __name__ == "__main__":
    main()
