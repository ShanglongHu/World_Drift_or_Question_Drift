"""Supplementary checks for identity collision and missed compatibility.

Identity collision: two questions agree in an initially symmetric regime, so a
value-only rule merges them. Their answers later diverge while their question
identities remain distinct.

Missed compatibility: a question receives a new, separately versioned
implementation while its scoped probe law remains unchanged. A syntax-only
rule cold-starts a new answer; a compatibility-aware rule reuses the estimate
without merging the two question IDs.
"""

from __future__ import annotations

import csv
from pathlib import Path

import numpy as np


SEEDS = 200
ALPHA = 0.05
PHASE_STEPS = 400
EARLY_WINDOW = 50
SENSITIVITY_WINDOWS = (25, 50, 100)


def update(value: float, target: float) -> float:
    return value + ALPHA * (target - value)


def identity_collision(seed: int) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    merged = 0.5
    separate = {"left": 0.5, "right": 0.5}

    # Symmetry makes the two distinct interventions observationally equal.
    for step in range(PHASE_STEPS):
        question = "left" if step % 2 == 0 else "right"
        sample = float(rng.random() < 0.5)
        merged = update(merged, sample)
        separate[question] = update(separate[question], sample)

    # A world change breaks the accidental equality.
    means = {"left": 0.2, "right": 0.8}
    for step in range(PHASE_STEPS):
        question = "left" if step % 2 == 0 else "right"
        sample = float(rng.random() < means[question])
        merged = update(merged, sample)
        separate[question] = update(separate[question], sample)

    merged_mae = np.mean([abs(merged - means[q]) for q in means])
    separate_mae = np.mean([abs(separate[q] - means[q]) for q in means])
    return float(merged_mae), float(separate_mae)


def missed_compatibility(seed: int, early_window: int = EARLY_WINDOW) -> tuple[float, float]:
    rng = np.random.default_rng(10_000 + seed)
    old = 0.5
    for _ in range(PHASE_STEPS):
        old = update(old, float(rng.random() < 0.2))

    syntax_new = 0.5
    compatible_reuse = old
    syntax_errors: list[float] = []
    reuse_errors: list[float] = []
    for step in range(PHASE_STEPS):
        sample = float(rng.random() < 0.2)
        syntax_new = update(syntax_new, sample)
        compatible_reuse = update(compatible_reuse, sample)
        if step < early_window:
            syntax_errors.append(abs(syntax_new - 0.2))
            reuse_errors.append(abs(compatible_reuse - 0.2))
    return float(np.mean(syntax_errors)), float(np.mean(reuse_errors))


def summarize(values: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    return values.mean(axis=0), values.std(axis=0, ddof=1) / np.sqrt(SEEDS)


def main() -> None:
    collision = np.asarray([identity_collision(seed) for seed in range(SEEDS)])
    compatibility = np.asarray([missed_compatibility(seed) for seed in range(SEEDS)])
    collision_mean, collision_se = summarize(collision)
    compatibility_mean, compatibility_se = summarize(compatibility)

    output = Path(__file__).with_name("identity_error_results.csv")
    rows = [
        ("identity_collision", "value_only_merge", collision_mean[0], collision_se[0]),
        ("identity_collision", "separate_question_ids", collision_mean[1], collision_se[1]),
        ("missed_compatibility", "syntax_only_cold_start", compatibility_mean[0], compatibility_se[0]),
        ("verified_compatibility", "estimate_reuse", compatibility_mean[1], compatibility_se[1]),
    ]
    with output.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["case", "method", "mae_mean", "mae_se"])
        writer.writerows(rows)

    sensitivity = Path(__file__).with_name("identity_error_sensitivity.csv")
    with sensitivity.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["early_window", "syntax_only_cold_start_mean", "syntax_only_cold_start_se", "estimate_reuse_mean", "estimate_reuse_se"])
        for window in SENSITIVITY_WINDOWS:
            values = np.asarray([missed_compatibility(seed, window) for seed in range(SEEDS)])
            means, ses = summarize(values)
            writer.writerow([window, means[0], ses[0], means[1], ses[1]])
    for case, method, mean, se in rows:
        print(f"{case:16s} {method:24s} {mean:.3f}+/-{se:.3f}")


if __name__ == "__main__":
    main()
