"""Pre-specified continual query panel for cross-checkpoint evaluation.

The experiment reuses the GridWorld, rollout predictor, and loss from
``drift_gridworld.py``.  It trains a fixed stream of twelve action/horizon
queries and evaluates the full panel after every phase.  Unseen-query scores
are retained in the raw file but excluded from historical-query metrics.

Run a quick precheck:
    python continual_query_panel.py --seeds 0 1 --tag precheck

Run the paper experiment (seeds 10--19; 0--1 are smoke-test only):
    python continual_query_panel.py
"""

from __future__ import annotations

import argparse
import csv
import random
from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch

import drift_gridworld as base


ACTIONS = {"up": 0, "down": 1, "left": 2, "right": 3}
HORIZONS = (1, 3, 5)
QUERY_ORDER = (
    "left-1", "left-3", "left-5",
    "right-5", "right-3", "right-1",
    "up-1", "up-3", "up-5",
    "down-5", "down-3", "down-1",
)
QUERIES = {
    f"{action}-{horizon}": (token,) * horizon
    for action, token in ACTIONS.items()
    for horizon in HORIZONS
}
# Seeds 0 and 1 are reserved for smoke testing; the reported run is disjoint.
SEEDS = tuple(range(10, 20))
PHASE_STEPS = 600
BATCH = 96
REPLAY_FRACTION = 0.2
LEARNING_RATE = 2e-3


@dataclass(frozen=True)
class Method:
    key: str
    label: str
    conditioned: bool
    replay: bool


METHODS = (
    Method("shared_head", "Shared head", conditioned=False, replay=False),
    Method("replay_no_identity", "Replay, no identity", conditioned=False, replay=True),
    Method("query_conditioned_replay", "Query-conditioned replay", conditioned=True, replay=True),
)


def query_features(name: str) -> np.ndarray:
    actions = QUERIES[name]
    tokens = list(actions) + [base.PAD] * (base.MAX_HORIZON - len(actions))
    encoded = np.zeros(base.MAX_HORIZON * (base.N_ACTIONS + 1) + base.MAX_HORIZON, dtype=np.float32)
    for index, token in enumerate(tokens):
        encoded[index * (base.N_ACTIONS + 1) + token] = 1.0
    encoded[base.MAX_HORIZON * (base.N_ACTIONS + 1) + len(actions) - 1] = 1.0
    return encoded


QUERY_FEATURES = {name: query_features(name) for name in QUERY_ORDER}
QUERY_DIM = len(next(iter(QUERY_FEATURES.values())))


def make_batch(
    rng: np.random.Generator,
    question: str,
    conditioned: bool,
    size: int,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    states = rng.choice(base.FREE_STATES, size=size, replace=True)
    query = QUERY_FEATURES[question] if conditioned else np.zeros(QUERY_DIM, dtype=np.float32)
    inputs = np.zeros((size, base.N_STATES + QUERY_DIM), dtype=np.float32)
    inputs[np.arange(size), states] = 1.0
    inputs[:, base.N_STATES:] = query
    outcomes = [base.rollout(int(state), QUERIES[question]) for state in states]
    targets = np.asarray([outcome[0] for outcome in outcomes], dtype=np.int64)
    collisions = np.asarray([outcome[1] for outcome in outcomes], dtype=np.float32)
    return torch.from_numpy(inputs), torch.from_numpy(targets), torch.from_numpy(collisions)


@torch.no_grad()
def evaluate(model: base.RolloutPredictor, question: str, conditioned: bool) -> dict[str, float]:
    # Exact repeated panel: deterministic and independent of training RNG state.
    states = np.repeat(base.FREE_STATES, 4)
    query = QUERY_FEATURES[question] if conditioned else np.zeros(QUERY_DIM, dtype=np.float32)
    inputs = np.zeros((len(states), base.N_STATES + QUERY_DIM), dtype=np.float32)
    inputs[np.arange(len(states)), states] = 1.0
    inputs[:, base.N_STATES:] = query
    outcomes = [base.rollout(int(state), QUERIES[question]) for state in states]
    targets = torch.tensor([outcome[0] for outcome in outcomes], dtype=torch.long)
    collisions = torch.tensor([outcome[1] for outcome in outcomes], dtype=torch.float32)
    state_logits, collision_logits = model(torch.from_numpy(inputs))
    loss = torch.nn.functional.cross_entropy(state_logits, targets)
    loss += torch.nn.functional.binary_cross_entropy_with_logits(collision_logits, collisions)
    terminal_error = (state_logits.argmax(dim=1) != targets).float().mean()
    collision_error = ((collision_logits >= 0).float() != collisions).float().mean()
    # Equal-weight average of two 0/1 errors; unlike cross-entropy, this is in [0, 1].
    bounded_error = 0.5 * (terminal_error + collision_error)
    return {"loss": float(loss), "bounded_error": float(bounded_error)}


def replay_schedule(seed: int) -> tuple[tuple[str | None, ...], ...]:
    """Precompute old-query choices, shared exactly by both replay methods."""
    rng = np.random.default_rng(100_000 + seed)
    phases: list[tuple[str | None, ...]] = []
    for checkpoint in range(len(QUERY_ORDER)):
        if checkpoint == 0:
            phases.append((None,) * PHASE_STEPS)
        else:
            previous = QUERY_ORDER[:checkpoint]
            phases.append(tuple(previous[int(rng.integers(len(previous)))] for _ in range(PHASE_STEPS)))
    return tuple(phases)


def self_checks() -> None:
    features = list(QUERY_FEATURES.values())
    assert len(features) == 12
    assert all(feature.shape == (QUERY_DIM,) for feature in features)
    assert len({feature.tobytes() for feature in features}) == 12
    check_rng = np.random.default_rng(2026)
    unconditioned, _, _ = make_batch(check_rng, "right-5", conditioned=False, size=4)
    assert torch.count_nonzero(unconditioned[:, base.N_STATES:]) == 0
    check_rng = np.random.default_rng(2026)
    conditioned, _, _ = make_batch(check_rng, "right-5", conditioned=True, size=4)
    expected = torch.from_numpy(QUERY_FEATURES["right-5"])
    assert torch.equal(conditioned[0, base.N_STATES:], expected)
    assert torch.equal(conditioned[-1, base.N_STATES:], expected)
    assert all(choice is None for choice in replay_schedule(0)[0])
    assert replay_schedule(7) == replay_schedule(7)

    model = base.RolloutPredictor()
    first = evaluate(model, QUERY_ORDER[0], conditioned=True)
    second = evaluate(model, QUERY_ORDER[0], conditioned=True)
    assert first == second


def run_seed(seed: int, method: Method) -> list[dict[str, object]]:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(1)
    data_rng = np.random.default_rng(seed)
    schedule = replay_schedule(seed)
    model = base.RolloutPredictor()
    optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)
    rows: list[dict[str, object]] = []

    for checkpoint, live_query in enumerate(QUERY_ORDER):
        for update in range(PHASE_STEPS):
            batches = []
            live_size = BATCH
            if method.replay and checkpoint > 0:
                old_size = int(BATCH * REPLAY_FRACTION)
                live_size -= old_size
                old_query = schedule[checkpoint][update]
                assert old_query is not None
                batches.append(make_batch(data_rng, old_query, method.conditioned, old_size))
            batches.append(make_batch(data_rng, live_query, method.conditioned, live_size))
            base.train_step(model, optimizer, batches)

        for query_index, eval_query in enumerate(QUERY_ORDER):
            scores = evaluate(model, eval_query, method.conditioned)
            rows.append(
                {
                    "seed": seed,
                    "method": method.key,
                    "checkpoint": checkpoint + 1,
                    "trained_query": live_query,
                    "eval_query": eval_query,
                    "seen": int(query_index <= checkpoint),
                    "loss": scores["loss"],
                    "bounded_error": scores["bounded_error"],
                }
            )
    return rows


def write_csv(path: Path, rows: list[dict[str, object]], fieldnames: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def summarize(raw_rows: list[dict[str, object]], seeds: tuple[int, ...]) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    query_rows: list[dict[str, object]] = []
    metric_rows: list[dict[str, object]] = []
    n = len(seeds)

    for method in METHODS:
        method_rows = [row for row in raw_rows if row["method"] == method.key]
        for checkpoint, trained_query in enumerate(QUERY_ORDER, start=1):
            checkpoint_rows = [row for row in method_rows if row["checkpoint"] == checkpoint]
            for eval_query in QUERY_ORDER:
                values = np.asarray([row["loss"] for row in checkpoint_rows if row["eval_query"] == eval_query], dtype=float)
                assert len(values) == n
                query_rows.append(
                    {
                        "method": method.key,
                        "checkpoint": checkpoint,
                        "trained_query": trained_query,
                        "eval_query": eval_query,
                        "seen": int(QUERY_ORDER.index(eval_query) < checkpoint),
                        "mean": values.mean(),
                        "standard_error": values.std(ddof=1) / np.sqrt(n) if n > 1 else float("nan"),
                        "bounded_mean": np.mean([float(row["bounded_error"]) for row in checkpoint_rows if row["eval_query"] == eval_query]),
                        "bounded_standard_error": np.std([float(row["bounded_error"]) for row in checkpoint_rows if row["eval_query"] == eval_query], ddof=1) / np.sqrt(n) if n > 1 else float("nan"),
                    }
                )

            per_seed_live = []
            per_seed_past = []
            per_seed_live_bounded = []
            per_seed_past_bounded = []
            for seed in seeds:
                seed_rows = [row for row in checkpoint_rows if row["seed"] == seed]
                live = next(float(row["loss"]) for row in seed_rows if row["eval_query"] == trained_query)
                past = [float(row["loss"]) for row in seed_rows if row["seen"] and row["eval_query"] != trained_query]
                live_bounded = next(float(row["bounded_error"]) for row in seed_rows if row["eval_query"] == trained_query)
                past_bounded = [float(row["bounded_error"]) for row in seed_rows if row["seen"] and row["eval_query"] != trained_query]
                per_seed_live.append(live)
                per_seed_past.append(float(np.mean(past)) if past else float("nan"))
                per_seed_live_bounded.append(live_bounded)
                per_seed_past_bounded.append(float(np.mean(past_bounded)) if past_bounded else float("nan"))
            live_values = np.asarray(per_seed_live)
            past_values = np.asarray(per_seed_past)
            valid_past = past_values[~np.isnan(past_values)]
            live_bounded_values = np.asarray(per_seed_live_bounded)
            past_bounded_values = np.asarray(per_seed_past_bounded)
            valid_past_bounded = past_bounded_values[~np.isnan(past_bounded_values)]
            metric_rows.append(
                {
                    "method": method.key,
                    "checkpoint": checkpoint,
                    "trained_query": trained_query,
                    "live_loss": live_values.mean(),
                    "live_standard_error": live_values.std(ddof=1) / np.sqrt(n) if n > 1 else float("nan"),
                    "past_loss": valid_past.mean() if len(valid_past) else float("nan"),
                    "past_standard_error": valid_past.std(ddof=1) / np.sqrt(len(valid_past)) if len(valid_past) > 1 else float("nan"),
                    "live_to_past_gap": valid_past.mean() - live_values.mean() if len(valid_past) else float("nan"),
                    "live_bounded_error": live_bounded_values.mean(),
                    "live_bounded_standard_error": live_bounded_values.std(ddof=1) / np.sqrt(n) if n > 1 else float("nan"),
                    "past_bounded_error": valid_past_bounded.mean() if len(valid_past_bounded) else float("nan"),
                    "past_bounded_standard_error": valid_past_bounded.std(ddof=1) / np.sqrt(len(valid_past_bounded)) if len(valid_past_bounded) > 1 else float("nan"),
                    "bounded_live_to_past_gap": valid_past_bounded.mean() - live_bounded_values.mean() if len(valid_past_bounded) else float("nan"),
                }
            )
    return query_rows, metric_rows


def gate_results(metric_rows: list[dict[str, object]]) -> dict[str, object]:
    shared = [row for row in metric_rows if row["method"] == "shared_head" and row["checkpoint"] >= 2]
    conditioned = [row for row in metric_rows if row["method"] == "query_conditioned_replay" and row["checkpoint"] >= 2]
    shared_past_gt_live = sum(float(row["past_loss"]) > float(row["live_loss"]) for row in shared)
    ratio = np.mean([float(row["past_loss"]) for row in shared]) / np.mean([float(row["live_loss"]) for row in shared])
    conditioned_better = sum(float(c["past_loss"]) < float(s["past_loss"]) for c, s in zip(conditioned, shared))
    shared_bounded_gt_live = sum(float(row["past_bounded_error"]) > float(row["live_bounded_error"]) for row in shared)
    conditioned_bounded_better = sum(float(c["past_bounded_error"]) < float(s["past_bounded_error"]) for c, s in zip(conditioned, shared))
    finite = all(np.isfinite(float(row[key])) for row in metric_rows for key in ("live_loss",) if row["checkpoint"] >= 1)
    finite = finite and all(np.isfinite(float(row["past_loss"])) for row in metric_rows if row["checkpoint"] >= 2)
    passed = (
        shared_past_gt_live >= 8
        and ratio > 10
        and conditioned_better >= 8
        and shared_bounded_gt_live >= 8
        and conditioned_bounded_better >= 8
        and finite
    )
    return {
        "shared_past_gt_live_checkpoints": shared_past_gt_live,
        "shared_mean_past_to_live_ratio": ratio,
        "conditioned_better_checkpoints": conditioned_better,
        "shared_bounded_past_gt_live_checkpoints": shared_bounded_gt_live,
        "conditioned_bounded_better_checkpoints": conditioned_bounded_better,
        "finite": finite,
        "passed": passed,
    }


def aggregate_bars(raw_rows: list[dict[str, object]], seeds: tuple[int, ...]) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    live = np.zeros((len(METHODS), len(seeds)))
    past = np.zeros_like(live)
    for method_index, method in enumerate(METHODS):
        for seed_index, seed in enumerate(seeds):
            seed_rows = [row for row in raw_rows if row["method"] == method.key and row["seed"] == seed]
            live_values, past_values = [], []
            for checkpoint, trained_query in enumerate(QUERY_ORDER, start=1):
                if checkpoint == 1:
                    continue
                checkpoint_rows = [row for row in seed_rows if row["checkpoint"] == checkpoint]
                live_values.append(next(float(row["bounded_error"]) for row in checkpoint_rows if row["eval_query"] == trained_query))
                past_values.append(np.mean([float(row["bounded_error"]) for row in checkpoint_rows if row["seen"] and row["eval_query"] != trained_query]))
            live[method_index, seed_index] = np.mean(live_values)
            past[method_index, seed_index] = np.mean(past_values)
    divisor = np.sqrt(len(seeds))
    ddof = 1 if len(seeds) > 1 else 0
    return live.mean(1), live.std(1, ddof=ddof) / divisor, past.mean(1), past.std(1, ddof=ddof) / divisor


def aggregate_by_query_age(raw_rows: list[dict[str, object]], seeds: tuple[int, ...]) -> tuple[np.ndarray, np.ndarray]:
    """Average bounded error after 0--11 subsequent query switches."""
    means = np.full((len(METHODS), len(QUERY_ORDER)), np.nan)
    errors = np.full_like(means, np.nan)
    for method_index, method in enumerate(METHODS):
        for age in range(len(QUERY_ORDER)):
            per_seed = []
            for seed in seeds:
                values = []
                for row in raw_rows:
                    if row["method"] != method.key or row["seed"] != seed or not row["seen"]:
                        continue
                    learned_at = QUERY_ORDER.index(str(row["eval_query"]))
                    observed_at = int(row["checkpoint"]) - 1
                    if observed_at - learned_at == age:
                        values.append(float(row["bounded_error"]))
                per_seed.append(float(np.mean(values)))
            values_array = np.asarray(per_seed, dtype=float)
            means[method_index, age] = values_array.mean()
            errors[method_index, age] = values_array.std(ddof=1) / np.sqrt(len(seeds)) if len(seeds) > 1 else 0.0
    return means, errors


def aggregate_hidden_error(raw_rows: list[dict[str, object]], seeds: tuple[int, ...]) -> tuple[np.ndarray, np.ndarray]:
    """Paired past-minus-live bounded error, averaged over checkpoints 2--12."""
    values = np.zeros((len(METHODS), len(seeds)))
    for method_index, method in enumerate(METHODS):
        for seed_index, seed in enumerate(seeds):
            gaps = []
            seed_rows = [row for row in raw_rows if row["method"] == method.key and row["seed"] == seed]
            for checkpoint, trained_query in enumerate(QUERY_ORDER, start=1):
                if checkpoint == 1:
                    continue
                checkpoint_rows = [row for row in seed_rows if row["checkpoint"] == checkpoint]
                live = next(float(row["bounded_error"]) for row in checkpoint_rows if row["eval_query"] == trained_query)
                past = np.mean([float(row["bounded_error"]) for row in checkpoint_rows if row["seen"] and row["eval_query"] != trained_query])
                gaps.append(past - live)
            values[method_index, seed_index] = np.mean(gaps)
    ddof = 1 if len(seeds) > 1 else 0
    return values.mean(axis=1), values.std(axis=1, ddof=ddof) / np.sqrt(len(seeds))


def plot_figure(query_rows: list[dict[str, object]], raw_rows: list[dict[str, object]], seeds: tuple[int, ...], output_prefix: Path) -> None:
    plt.rcParams.update({"font.size": 8.5, "axes.titlesize": 8.5, "axes.labelsize": 8.0, "xtick.labelsize": 7.2, "ytick.labelsize": 7.2, "legend.fontsize": 7.2})
    matrix = np.full((len(QUERY_ORDER), len(QUERY_ORDER)), np.nan)
    for row in query_rows:
        if row["method"] == "shared_head" and row["seen"]:
            matrix[int(row["checkpoint"]) - 1, QUERY_ORDER.index(str(row["eval_query"]))] = float(row["bounded_mean"])

    fig = plt.figure(figsize=(6.4, 2.30))
    grid = fig.add_gridspec(1, 3, width_ratios=(1.0, 1.0, 1.15), wspace=0.42)
    axes = [fig.add_subplot(grid[0, index]) for index in range(3)]
    cmap = plt.get_cmap("magma").copy()
    cmap.set_bad("#E2E5E9")
    short = [name.replace("left", "L").replace("right", "R").replace("up", "U").replace("down", "D") for name in QUERY_ORDER]
    ax = axes[0]
    image = ax.imshow(matrix, aspect="auto", interpolation="nearest", cmap=cmap, vmin=0.0, vmax=1.0)
    ax.set_title("A  Fixed-query error", loc="left", fontweight="bold", pad=4)
    ax.set_xticks(np.arange(12), short, rotation=65, ha="right")
    ax.set_yticks(np.arange(12), np.arange(1, 13))
    ax.set_ylabel("Checkpoint")
    ax.tick_params(length=0)
    cbar = fig.colorbar(image, ax=ax, location="bottom", fraction=0.055, pad=0.23, aspect=28)
    cbar.set_label("Bounded error", labelpad=1)
    cbar.set_ticks([0.0, 0.25, 0.5, 0.75, 1.0])

    age_mean, age_se = aggregate_by_query_age(raw_rows, seeds)
    ax = axes[1]
    age = np.arange(len(QUERY_ORDER))
    # Plot every method separately. The two identity-blind curves nearly
    # overlap, so distinct line styles and marker shapes preserve transparency.
    ax.plot(age, age_mean[1], marker="s", markerfacecolor="white", markersize=4.2,
            markeredgewidth=1.1, linewidth=1.25, linestyle="--", color="#F2A541",
            label="Replay, no ID", zorder=2)
    ax.plot(age, age_mean[0], marker="o", markersize=2.7, linewidth=1.15,
            color="#D62728", label="Shared", zorder=3)
    ax.plot(age, age_mean[2], marker="^", markersize=3.0, linewidth=1.25,
            color="#4C78A8", label="Query-cond. replay", zorder=4)
    ax.set_title("B  Error vs. query age", loc="left", fontweight="bold", pad=4)
    ax.set_xlabel("Query age (switches)")
    ax.set_ylabel("Bounded error")
    ax.set_xlim(-0.2, 11.2)
    ax.set_ylim(-0.02, 1.5)
    ax.set_xticks((0, 3, 6, 9, 11))
    ax.set_yticks((0.0, 0.5, 1.0, 1.5))
    ax.legend(frameon=False, loc="upper left", handlelength=1.2, labelspacing=0.15, borderaxespad=0.2)
    ax.spines[["top", "right"]].set_visible(False)

    live_mean, _, _, _ = aggregate_bars(raw_rows, seeds)
    hidden_mean, hidden_se = aggregate_hidden_error(raw_rows, seeds)
    x = np.arange(len(METHODS))
    ax = axes[2]
    colors = ("#D62728", "#F2A541", "#4C78A8")
    ax.bar(x, hidden_mean, width=0.54, yerr=hidden_se, color=colors, capsize=2, zorder=2)
    for index in range(len(METHODS)):
        label = "near 0" if hidden_mean[index] < 1e-3 else f"{hidden_mean[index]:.2f}"
        ax.annotate(label, (x[index], hidden_mean[index]), xytext=(0, 5), textcoords="offset points",
                    ha="center", va="bottom", fontsize=7.0, color="#374151", fontweight="bold")
    ax.set_title("C  Error hidden by live-only scoring", loc="left", fontweight="bold", pad=4)
    ax.set_ylabel("Past $-$ live error")
    ax.set_ylim(0.0, 0.8)
    ax.set_yticks((0.0, 0.25, 0.5, 0.75))
    ax.set_xticks(x, ("Shared", "No ID", "Query-cond.\nreplay"))
    ax.set_xlim(-0.55, 2.55)
    ax.spines[["top", "right"]].set_visible(False)
    fig.subplots_adjust(left=0.065, right=0.995, top=0.86, bottom=0.35)
    fig.savefig(output_prefix.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(output_prefix.with_suffix(".png"), dpi=240, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seeds", nargs="+", type=int, default=list(SEEDS))
    parser.add_argument("--tag", default="")
    parser.add_argument("--plot-only", action="store_true")
    args = parser.parse_args()
    seeds = tuple(args.seeds)
    self_checks()

    suffix = f"_{args.tag}" if args.tag else ""
    output_dir = Path(__file__).parent
    raw_path = output_dir / f"continual_query_panel_raw{suffix}.csv"
    query_path = output_dir / f"continual_query_panel_query_summary{suffix}.csv"
    metric_path = output_dir / f"continual_query_panel_checkpoint_summary{suffix}.csv"
    figure_prefix = output_dir / f"continual_query_panel{suffix}"
    if args.plot_only:
        with raw_path.open(encoding="utf-8") as stream:
            raw_rows = list(csv.DictReader(stream))
        for row in raw_rows:
            row["seed"] = int(row["seed"])
            row["checkpoint"] = int(row["checkpoint"])
            row["seen"] = int(row["seen"])
            row["loss"] = float(row["loss"])
            row["bounded_error"] = float(row["bounded_error"])
        with query_path.open(encoding="utf-8") as stream:
            query_rows = list(csv.DictReader(stream))
        for row in query_rows:
            row["checkpoint"] = int(row["checkpoint"])
            row["seen"] = int(row["seen"])
            row["mean"] = float(row["mean"])
            row["standard_error"] = float(row["standard_error"])
            row["bounded_mean"] = float(row["bounded_mean"])
            row["bounded_standard_error"] = float(row["bounded_standard_error"])
        plot_figure(query_rows, raw_rows, seeds, figure_prefix)
        print(f"redrew {figure_prefix.with_suffix('.pdf').name}")
        return

    raw_rows: list[dict[str, object]] = []
    for method in METHODS:
        for seed in seeds:
            print(f"running {method.key}, seed {seed}", flush=True)
            raw_rows.extend(run_seed(seed, method))

    write_csv(raw_path, raw_rows, ["seed", "method", "checkpoint", "trained_query", "eval_query", "seen", "loss", "bounded_error"])
    query_rows, metric_rows = summarize(raw_rows, seeds)
    write_csv(query_path, query_rows, ["method", "checkpoint", "trained_query", "eval_query", "seen", "mean", "standard_error", "bounded_mean", "bounded_standard_error"])
    write_csv(metric_path, metric_rows, ["method", "checkpoint", "trained_query", "live_loss", "live_standard_error", "past_loss", "past_standard_error", "live_to_past_gap", "live_bounded_error", "live_bounded_standard_error", "past_bounded_error", "past_bounded_standard_error", "bounded_live_to_past_gap"])
    plot_figure(query_rows, raw_rows, seeds, figure_prefix)

    gate = gate_results(metric_rows)
    for key, value in gate.items():
        print(f"{key}: {value}")
    if not gate["passed"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
