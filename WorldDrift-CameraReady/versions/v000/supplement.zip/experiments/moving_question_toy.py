"""Minimal moving-question experiment for the Idea Track paper.

A one-state continuing process exposes one active Bernoulli cumulant at a time.
The active predictive question switches from q_L (mean .2) to q_R (mean .8).
All learners use the same constant-step-size update. The only difference is
whether the answer is indexed by question identity.
"""

from __future__ import annotations

import csv
from pathlib import Path

import numpy as np


SEEDS = 200
STEPS_PER_PHASE = 400
ALPHA = 0.05
MEANS = {"q_L": 0.2, "q_R": 0.8}


def update(value: float, target: float) -> float:
    return value + ALPHA * (target - value)


def run_seed(seed: int) -> dict[str, tuple[float, float]]:
    rng = np.random.default_rng(seed)
    shared = 0.5
    replay = 0.5
    registry = {"q_L": 0.5, "q_R": 0.5}
    replay_buffer: list[float] = []

    for question in ("q_L", "q_R"):
        for _ in range(STEPS_PER_PHASE):
            sample = float(rng.random() < MEANS[question])
            shared = update(shared, sample)

            replay_buffer.append(sample)
            replay_sample = replay_buffer[rng.integers(len(replay_buffer))]
            replay = update(replay, replay_sample)

            registry[question] = update(registry[question], sample)

    return {
        "shared head": (abs(shared - MEANS["q_L"]), abs(shared - MEANS["q_R"])),
        "replay, no identity": (
            abs(replay - MEANS["q_L"]),
            abs(replay - MEANS["q_R"]),
        ),
        "question registry": (
            abs(registry["q_L"] - MEANS["q_L"]),
            abs(registry["q_R"] - MEANS["q_R"]),
        ),
    }


def main() -> None:
    rows = [run_seed(seed) for seed in range(SEEDS)]
    output = Path(__file__).with_name("results.csv")
    with output.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["method", "old_question_mae_mean", "old_question_mae_se", "current_question_mae_mean", "current_question_mae_se"]
        )
        for method in rows[0]:
            values = np.asarray([row[method] for row in rows])
            means = values.mean(axis=0)
            ses = values.std(axis=0, ddof=1) / np.sqrt(SEEDS)
            writer.writerow([method, means[0], ses[0], means[1], ses[1]])
            print(
                f"{method:20s} old={means[0]:.3f}+/-{ses[0]:.3f} "
                f"current={means[1]:.3f}+/-{ses[1]:.3f}"
            )


if __name__ == "__main__":
    main()
