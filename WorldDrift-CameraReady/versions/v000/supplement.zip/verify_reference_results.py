"""Check packaged CSV outputs against the v3.63 paper headline values."""

from __future__ import annotations

import csv
from pathlib import Path


BASE = Path(__file__).resolve().parent
ROOT = BASE / "experiments" if (BASE / "experiments").is_dir() else BASE


def rows(name: str) -> list[dict[str, str]]:
    with (ROOT / name).open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def close(actual: float, expected: float, tolerance: float, label: str) -> None:
    if abs(actual - expected) > tolerance:
        raise AssertionError(
            f"{label}: got {actual:.8g}, expected {expected:.8g} +/- {tolerance:g}"
        )
    print(f"PASS  {label}: {actual:.8g}")


def main() -> None:
    analytic = {row["method"]: row for row in rows("results.csv")}
    close(float(analytic["question registry"]["old_question_mae_mean"]), 0.052, 0.003, "analytic registry old")
    close(float(analytic["replay, no identity"]["old_question_mae_mean"]), 0.292, 0.003, "analytic replay old")

    rollout = {(row["method"], row["query"]): row for row in rows("drift_gridworld_results.csv")}
    close(float(rollout[("shared head", "old_q_left_3")]["loss_mean"]), 24.25, 0.02, "rollout shared old")
    close(float(rollout[("query-conditioned replay", "old_q_left_3")]["loss_mean"]), 0.0018, 0.0004, "rollout conditioned old")

    summary = {row["metric"]: float(row["value"]) for row in rows("three_arm_attribution_summary.csv")}
    close(summary["world_delta_mean"], 0.205, 0.002, "three-arm world")
    close(summary["question_delta_mean"], 0.204, 0.002, "three-arm question")
    close(summary["learner_delta_mean"], 0.208, 0.002, "three-arm learner")
    close(summary["output_only_accuracy"], 0.356, 0.002, "output-only attribution")

    identity = {(row["case"], row["method"]): row for row in rows("identity_error_results.csv")}
    close(float(identity[("identity_collision", "value_only_merge")]["mae_mean"]), 0.300, 1e-10, "identity collision merge")
    close(float(identity[("missed_compatibility", "syntax_only_cold_start")]["mae_mean"]), 0.110, 0.003, "missed compatibility cold start")
    close(float(identity[("verified_compatibility", "estimate_reuse")]["mae_mean"]), 0.052, 0.003, "verified compatibility reuse")

    panel = rows("continual_query_panel_checkpoint_summary.csv")
    if len(panel) != 36:
        raise AssertionError(f"continual panel summary has {len(panel)} rows, expected 36")
    expected = {
        "shared_head": (0.000000, 0.680500),
        "replay_no_identity": (0.000500, 0.680100),
        "query_conditioned_replay": (0.000000, 0.000020),
    }
    for method, (live, past) in expected.items():
        subset = [row for row in panel if row["method"] == method and int(row["checkpoint"]) >= 2]
        close(sum(float(row["live_bounded_error"]) for row in subset) / len(subset), live, 0.00002, f"panel {method} live")
        close(sum(float(row["past_bounded_error"]) for row in subset) / len(subset), past, 0.00002, f"panel {method} past")

    print("All packaged headline results match the v3.63 paper.")


if __name__ == "__main__":
    main()
