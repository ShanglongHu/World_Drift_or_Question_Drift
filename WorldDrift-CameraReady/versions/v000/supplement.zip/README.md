# Reproduction

`moving_question_toy.py` reproduces the analytic GVF check cited in the paper. It isolates the measurement failure caused by routing two explicit GVF questions through one unconditioned answer.

The packaged artifacts correspond to the paper as follows: the analytic check gives Table 1; the 12-query continual panel gives Figure 2; the learned two-query rollout gives Table 2 and Figure 3; the three-arm audit gives Table 3 and Figure 4; and the identity-collision/missed-compatibility checks give Table 4.

`drift_gridworld.py` trains a two-layer action-conditioned rollout predictor over 10 seeds. It maps state plus an action sequence and horizon to terminal occupancy and collision, writes `drift_gridworld_results.csv`, and generates the paper figure in PDF and PNG formats.

`continual_query_panel.py` reuses that environment, predictor, and loss on a fixed stream of 12 queries: four repeated actions crossed with horizons 1, 3, and 5. Each of 12 phases uses 600 Adam updates, batch size 96, learning rate `2e-3`, and reported seeds 10--19. Seeds 0--1 are reserved for the smoke test `python continual_query_panel.py --seeds 0 1 --tag precheck` and are disjoint from reporting. Replay occupies 20% of each batch and samples one earlier query uniformly; both replay methods use the same precomputed query schedule. Outputs include cross-entropy and a bounded average of terminal-state and collision 0--1 errors.

The panel uses the fixed order `L1, L3, L5, R5, R3, R1, U1, U3, U5, D5, D3, D1`. It writes `continual_query_panel_raw.csv`, `continual_query_panel_query_summary.csv`, `continual_query_panel_checkpoint_summary.csv`, and the corresponding PDF/PNG figure. The predeclared acceptance gates require, on checkpoints 2--12, at least 8/11 checkpoints with shared-head past error above live error, a shared-head mean past/live loss ratio above 10, and at least 8/11 checkpoints where query-conditioned replay improves past loss. The bounded-error versions must also satisfy the directional gates, and all reported values must be finite.

For any continuity audit, retain the realized finite probe set $B$ and its sampling rule $\mu$ alongside the reference environment, audit functional, discrepancy, tolerance, resampling unit, and rollout count.

`identity_error_cases.py` adds two supplementary checks:

- Identity collision: distinct left/right specifications are incorrectly assigned one identity because they agree in a symmetric regime, then fail after symmetry breaks.
- Missed compatibility: a successor implementation that passes the declared probe-compatibility test is cold-started unnecessarily.

The script writes `identity_error_sensitivity.csv` for the 25-, 50-, and 100-update early windows used to check the missed-compatibility conclusion. The default 50-update values remain in `identity_error_results.csv`.

`three_arm_attribution.py` trains a recurrent latent rollout model with state/layout encoders and occupancy/collision decoders. It uses 2,600 Adam updates, learning rate `2e-3`, batch size 128, and loss `CE + 2 BCE`. Five pilot seeds fix a stochastic-question mixture and learner-calibration coefficient; 30 disjoint seeds then evaluate isolated world, question, and learner interventions. Output-only attribution uncertainty is cluster-bootstrapped over the 30 seed groups. The script writes per-seed and summary CSV files and generates the two-panel attribution figure. The full deterministic CPU run takes several minutes because it trains 35 independent models.

`verify_reference_results.py` checks the headline values in all four experiment families and the continual panel summary without rerunning training.

The analytic and identity-error checks use 200 fixed seeds; the two-query rollout and continual panel use 10; the three-arm audit uses 5 pilot plus 30 held-out seeds. All scripts write CSV results beside the source. The analytic checks require Python and NumPy; learned-rollout experiments additionally require PyTorch and Matplotlib.
